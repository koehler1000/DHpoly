package observerpattern;

public interface Beobachter
{
	public void update();
}
