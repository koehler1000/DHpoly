package de.dhpoly.karte;

public interface Karte
{
	public String getBeschreibung();

	public String getTitel();
}
