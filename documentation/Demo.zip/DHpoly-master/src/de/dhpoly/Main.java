package de.dhpoly;

public class Main
{
	public static void main(String[] args)
	{
		// Spieler s1 = new SpielerImpl("Tester1", 1000);
		// Spieler s2 = new SpielerImpl("Tester2", 1000);
		// TODO erg�nzen
	}
}
