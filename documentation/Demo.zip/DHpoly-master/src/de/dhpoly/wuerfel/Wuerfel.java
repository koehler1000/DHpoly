package de.dhpoly.wuerfel;

public interface Wuerfel
{
	void wuerfeln();

	int getWuerfelErgebnisSumme();

	int getWuerfelErgebnis2();

	int getWuerfelErgebnis1();
}
