package de.dhpoly.kartenstapel;

import de.dhpoly.karte.Karte;

public interface Kartenstapel
{
	public Karte ziehen();
}
