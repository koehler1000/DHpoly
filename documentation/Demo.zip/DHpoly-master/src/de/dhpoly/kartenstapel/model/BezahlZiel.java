package de.dhpoly.kartenstapel.model;

public enum BezahlZiel
{
	FREIPARKEN, BANK, SPIELER_ZIEHER, SPIELER_ANDERE
}
