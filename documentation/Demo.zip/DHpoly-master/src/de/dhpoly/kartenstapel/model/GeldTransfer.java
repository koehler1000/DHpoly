package de.dhpoly.kartenstapel.model;

public enum GeldTransfer
{
	SPIELER_ANDERESPIELER,
	BANK_SPIELER,
	ANDERESPIELER_SPIELER
}
